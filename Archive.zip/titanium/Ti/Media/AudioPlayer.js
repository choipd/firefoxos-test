define(["Ti/_/declare", "Ti/_/Evented"], function(declare, Evented) {
	
	return declare("Ti.Media.AudioPlayer", Evented, {
	});

});